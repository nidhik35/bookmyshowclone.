
// Book my show planning

// -> We need a reusable carousel
//   -> Hero carousel
//   -> Common carousel
//   -> cast and crew small carousel


// Pages
// -> Home Page
// -> Movie Page
// -> Categories Page
// -> Auth Page
// -> Razorpay payment gateway

// Plan-> How are we building it????? 🤔
// Layouts
// Routes
// Pages 
// Components

// HOC
// Higher Order Components